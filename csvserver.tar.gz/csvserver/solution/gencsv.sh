#!/bin/bash
if [ $# -eq 0 ]
   then val=10
else 
	val=$1
fi
RANDOM=$$
rm -f inputFile
for j in `(seq 1 1 $val)`
do
     echo $j,$RANDOM >> inputFile
done

