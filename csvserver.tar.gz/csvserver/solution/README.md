git clone https://github.com/infracloudio/csvserver.git
docker run -d infracloudio/csvserver:latest
docker logs container-id
 docker inspect container-id
 docker history image-id --no-trunc
docker stop fe78af0673e0
docker rm fe78af0673e0
vim gencsv.sh
./gencsv.sh
docker exec -it b5ba4c0bc03b bash
docker run -d -e CSVSERVER_BORDER=Orange -p 9393:9300 -v /root/vishal/inputFile:/csvserver/inputdata infracloudio/csvserver:latest
docker pull prom/prometheus:v2.22.0
